# FuckFuckGo Android

A minimal launchable Android browser/search app.

## Build APK
1. Open this folder in Android Studio.
2. Allow Gradle sync to finish.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the generated debug APK from `app/build/outputs/apk/debug/app-debug.apk`.

Notes:
- Search queries currently use DuckDuckGo's public web search URL.
- This is an independent app and does not claim affiliation with DuckDuckGo.
