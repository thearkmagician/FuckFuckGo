plugins {
    id("com.android.application")
}

android {
    namespace = "com.fuckfuckgo.browser"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.fuckfuckgo.browser"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.core:core-ktx:1.15.0")
}
