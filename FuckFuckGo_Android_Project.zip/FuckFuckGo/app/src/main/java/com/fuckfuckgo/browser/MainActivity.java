package com.fuckfuckgo.browser;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.ImageButton;
import androidx.appcompat.app.AppCompatActivity;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public class MainActivity extends AppCompatActivity {
    private WebView webView;
    private EditText addressBar;

    @SuppressLint("SetJavaScriptEnabled")
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webView);
        addressBar = findViewById(R.id.addressBar);
        ImageButton back = findViewById(R.id.backButton);
        ImageButton forward = findViewById(R.id.forwardButton);
        ImageButton refresh = findViewById(R.id.refreshButton);
        ImageButton home = findViewById(R.id.homeButton);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setSafeBrowsingEnabled(true);

        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                addressBar.setText(url);
            }
        });

        addressBar.setOnEditorActionListener((v, actionId, event) -> {
            navigate(addressBar.getText().toString());
            return true;
        });
        addressBar.setOnKeyListener((v, keyCode, event) -> {
            if (keyCode == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_DOWN) {
                navigate(addressBar.getText().toString());
                return true;
            }
            return false;
        });

        back.setOnClickListener(v -> { if (webView.canGoBack()) webView.goBack(); });
        forward.setOnClickListener(v -> { if (webView.canGoForward()) webView.goForward(); });
        refresh.setOnClickListener(v -> webView.reload());
        home.setOnClickListener(v -> showHome());

        showHome();
    }

    private void navigate(String input) {
        String q = input.trim();
        if (q.isEmpty()) return;
        if (q.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*")) {
            webView.loadUrl(q);
        } else if (q.matches("^[^\\s]+\\.[^\\s]+$")) {
            webView.loadUrl("https://" + q);
        } else {
            webView.loadUrl("https://duckduckgo.com/?q=" +
                URLEncoder.encode(q, StandardCharsets.UTF_8));
        }
    }

    private void showHome() {
        String html = "<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'>" +
            "<style>body{margin:0;background:#0b0b0f;color:white;font-family:sans-serif;display:flex;min-height:100vh;" +
            "align-items:center;justify-content:center;text-align:center}.logo{font-size:42px;font-weight:900;letter-spacing:-2px}" +
            ".tag{color:#aaa;margin-top:10px}.pill{margin:28px auto 0;background:#1b1b23;border:1px solid #333;border-radius:24px;" +
            "padding:14px 18px;max-width:280px;color:#ccc}</style></head><body><div><div class='logo'>FuckFuckGo</div>" +
            "<div class='tag'>Search. Browse. Leave less behind.</div><div class='pill'>Type a search or URL above</div></div></body></html>";
        webView.loadDataWithBaseURL("https://localhost/", html, "text/html", "UTF-8", null);
        addressBar.setText("");
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
